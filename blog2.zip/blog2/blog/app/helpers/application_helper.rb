module ApplicationHelper
     
def css_for_flash(type)
    case type
    when 'notice'
        ' bg-green-100'
    when 'alert'
        'border-t-red-700'
    else
        'border-t-green-700'
    end
end
end
