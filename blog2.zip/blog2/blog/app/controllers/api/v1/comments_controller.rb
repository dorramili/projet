module Api
    module V1
        class CommentsController < ApiController

            def index
                comments = Comment.all.includes(:article)  

                render json: 
               {    
                   data: ActiveModelSerializers::SerializableResource.new(comments, each_serializer: Api::V1::CommentsSerializer),
                   message: ['Comment list fetched successfully'],
                   status: 200,
                   type: 'Success'
                }
            end

            def show
                comment = Comment.find(params[:id])

                render json: 
               {
                    data: ActiveModelSerializers::SerializableResource.new(comment, serializer: CommentsSerializer),
                    message: ['Comment profile fetched successfully'],
                    status: 200,
                    type: 'Success'
                }
                
            end
            def create
                article = Article.find(params[:article_id])
                comment = article.comments.create(comment_params)

                render json: 
               {
                    data: ActiveModelSerializers::SerializableResource.new(comment, serializer:CommentsController),
                    message: ['Comment profile fetched successfully'],
                    status: 200,
                    type: 'Success'
                }
            end

            def destroy
               
                comment = Comment.find(params[:id])
                comment.destroy

                render json: 
               {
                    #data: ActiveModelSerializers::SerializableResource.new(comment, serializer:CommentsController),
                    message: ['Comment destroyed successfully'],
                    status: 200,
                    type: 'Success'
                }
            end





            def create
                article = Article.find(params[:article_id])
                comment = article.comments.create(comment_params)
               

                render json: 
               {
                    data: ActiveModelSerializers::SerializableResource.new(article, serializer: ArticlesSerializer),
                    message: ['comment profile fetched successfully'],
                    status: 200,
                    type: 'Success'
                }
            end
           



            private
            def comment_params
                params.require(:comment).permit(:commenter, :body, :status)
            end

       end       
   end
end