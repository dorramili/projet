module Api
    module V1
        class ArticlesController < ApiController
            def index
                articles = Article.all.includes(:comments)
                render json: 
               {
                    data: ActiveModelSerializers::SerializableResource.new(articles, each_serializer: Api::V1::ArticlesSerializer),
                    message: ['Article list fetched successfully'],
                    status: 200,
                    type: 'Success'
                }
            end
            def show
                article = Article.find(params[:id])
                
                render json: 
               {
                  data: ActiveModelSerializers::SerializableResource.new(article, serializer: ArticlesSerializer),
                  message: ['Article profile fetched successfully'],
                  status: 200,
                  type: 'Success'
                }
            end
            def new
                article = Article.new
            end
            def create
                article = Article.new(article_params)
               if article.save

                render json: 
               {
                    data: ActiveModelSerializers::SerializableResource.new(article, serializer: ArticlesSerializer),
                    message: ['Article profile fetched successfully'],
                    status: 200,
                    type: 'Success'
                }
            end
            end

            def edit
                article = Article.find(params[:id])
              end
            
            def update
                article = Article.find(params[:id])
                article.update(article_params)

                render json: 
               {
                    data: ActiveModelSerializers::SerializableResource.new(article, serializer: ArticlesSerializer),
                    message: ['Article profile fetched successfully'],
                    status: 200,
                    type: 'Success'
                }

            end
            def destroy
                article = Article.find(params[:id])
                #comment = article.comments.find(params[:id])
                #comment = article.comments.create(comment_params)
                article.destroy
               
    
            end

            
            private
            def article_params
              params.require(:article).permit(:title, :body, :status)
            end 


        end
    end
end

