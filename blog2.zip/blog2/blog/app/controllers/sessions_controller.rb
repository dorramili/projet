class SessionsController < ApplicationController
  def create
  end

  def destroy
  end
end
