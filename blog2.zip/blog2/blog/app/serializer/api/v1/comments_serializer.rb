module Api
    module V1
        class CommentsSerializer < ActiveModel::Serializer
            attributes :commenter, :body, :status,  :article
          def article
            {
                title: object.article.title,
                body: object.article.body,
                status: object.article.status
            }
          end
        end
    end
end

