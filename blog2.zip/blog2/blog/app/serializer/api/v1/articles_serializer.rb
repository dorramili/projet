module Api
    module V1
        class ArticlesSerializer < ActiveModel::Serializer
          attributes :title, :body, :status, :comments

          
          def comments
            object.comments.map do |comment|
              {
                commenter: comment.commenter,
                body: comment.body,
                status: comment.status
              }
            end
          end

        end
    end
end