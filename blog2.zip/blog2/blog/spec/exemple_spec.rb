require 'rails_helper'

RSpec.describe 'valide article', type: :system do
 
  scenario 'valid title and url' do
    visit new_article_path
  
    # fill in text fields with specified string
    fill_in 'article_title', with: ''
    fill_in 'article_body', with: 'hhhh'
    click_button 'Create Article'
    
    # The page should show success message
   expect(page).to have_content("Title can't be blank")
   expect(page).to have_content("Body is too short (minimum is 10 characters)")

    # 1 new bookmark record is created
   # expect(Bookmark.count).to eq(1)
    
    # Optionally, you can check the latest record data
    #expect(Bookmark.last.title).to eq('RubyYagi')
  end
end