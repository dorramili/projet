require 'rails_helper'

RSpec.describe 'edit', type: :system do
  let(:article) { create(:article) }
  it 'editer un article' do
    visit article_path(article)
    click_link 'Edit'
   
    fill_in "article_title",        :with => "azertyuio"
    fill_in "article_body",        :with => "azertyuiop"
    click_button 'Update Article'
    expect(page).to have_content("azertyuio")
    expect(page).to have_content("azertyuiop")
    
    
  end
end

