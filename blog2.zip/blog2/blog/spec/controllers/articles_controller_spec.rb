require 'rails_helper'
describe ArticlesController do
    render_views
  
    # login to http basic auth
    include AuthHelper
    before(:each) do
      http_login
    end
  
    describe "GET 'index'" do
      it "should be successful" do
        get 'index'
      end
        
         #click_link 'New Article'
      
    end
  
  end