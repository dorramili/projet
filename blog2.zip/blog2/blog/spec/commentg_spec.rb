require 'rails_helper'

RSpec.describe 'testcomment', type: :system do
  let(:article) { create(:article) }
  it 'editer un commentaire' do
    visit article_path(article)
   
   
    fill_in "comment_commenter",        :with => "azertyuio"
    fill_in "comment_body",        :with => "azertyuiop"
    click_button 'Create Comment'
    expect(page).to have_content("created comment succeffuly")
    
    
    
  end
end

