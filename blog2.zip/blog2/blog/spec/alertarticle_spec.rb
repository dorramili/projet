require 'rails_helper'

RSpec.describe 'Articles', type: :system do
    
    it 'test alert' do
        visit new_article_path
        fill_in "article_title",        :with => ""
        fill_in "article_body",        :with => "rrr"
        click_button 'Create Article'
        expect(page).to have_content("Title can't be blank")
        expect(page).to have_content("Body is too short (minimum is 10 characters)")
      end

  it 'article creation' do
    visit new_article_path
    fill_in "article_title",        :with => "rached"
    fill_in "article_body",        :with => "rachedrached"
    click_button 'Create Article'
    expect(page).to have_content("rached")
    expect(page).to have_content("rachedrached")
  end

  it 'article creation(test alert)' do
    visit new_article_path
    fill_in "article_title",        :with => "test"
    fill_in "article_body",        :with => "testtesttest"
    click_button 'Create Article'
    expect(page).to have_content("created sucssefful")
    
  end

end