require 'rails_helper'

RSpec.describe 'test new article', type: :system do
  let(:article){create(:article)}
  
  it 'creation dun article' do
    visit article_path(article)
   
    expect(page).to have_content(article.title)
    
    #expect(page).to have_content("dorra")
  end
end


