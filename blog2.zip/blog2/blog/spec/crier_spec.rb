
  require 'rails_helper'

RSpec.describe 'comments', type: :system do
  let(:article) { create(:article) }
  it 'comment creation' do
    visit article_path(article)

    fill_in "comment_commenter",        :with => "dorra"
    fill_in "comment_body",        :with => "dorradorra"

    click_button 'Create Comment'

    expect(page).to have_content("dorra")
    expect(page).to have_content("dorradorra")
  end
end

