require 'rails_helper'

RSpec.describe 'authentification', type: :system do
   # let (:hacker) {FactoryGirl.create(:hacker)}
    

    scenario "visiting the site" do
    
            visit  root_path
        click_link "Sign up"
        fill_in "user_email", with: "dorra.mili1998@gmail.com"
        fill_in "user_password", with: "dorraDorra123."
        fill_in "user_password_confirmation", with: "dorraDorra123."
        click_button "commit"
        
        expect(page).to have_content("You have signed up successfully")
    end    
end       