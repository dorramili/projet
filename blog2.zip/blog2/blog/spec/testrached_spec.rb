require 'rails_helper'

RSpec.describe 'test new article', type: :system do
  let(:article){create(:article, :with_comments)}
  
  it 'creation comment' do
    visit article_path(article)
    expect(page).to have_content("dorra")
    
  end
  
end