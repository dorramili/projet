feature 'User does something' do
    include_context 'When authenticated'
  
    # test examples
  end