 # FactoryBot.define do
  # factory :article do
   #   title{"ttttt"}
    #  body {"bbbbbbbbbbbb"}
     # status{"archived"}
  # end

  #  trait :with_comments do
   #     after(:create) do |article|
    #     create(:comment, article_id: article.id )
     #  end
    # end

     #trait :with_faker_comments do
      #after(:create) do |article|
       #create(:comment_faker , article_id: article.id )
    # end
  # end
 # end
 FactoryBot.define do
  factory :article do  
      title { Faker::Name.name}
      body  { Faker::Config.random = Random.new(42)}
      status{ "public" }
  end
end



 

  