FactoryBot.define do
    factory :comment_faker,class:'Comment' do
        commenter { Faker::Name.name}
        body  { Faker::Company.catch_phrase }
        status{ "public" }
    end
end