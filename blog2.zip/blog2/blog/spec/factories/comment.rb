FactoryBot.define do
    factory :comment do
      commenter { "dorra"}
      body {"jsdqhshhss"}
      status {"public"}
    end
  end
  
  